<div class="card" style="width: 18rem;">
  <img src="imagenes/zoo.jpg" class="card-img-top" alt="imagenes/zoo.jpg">
  <h2>escoja el guia </h2>
  <div class="card-body">
    <p class="card-text"><div class="form-check">
  <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
  <label class="form-check-label" for="flexCheckDefault">
   
    Default checkbox
  </label>
</div>
<div class="form-check">
  <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" checked>
  <label class="form-check-label" for="flexCheckChecked">
    Checked checkbox
  </label>
  
</div></p>

<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> confirmar</a></li>

  </div>
</div>